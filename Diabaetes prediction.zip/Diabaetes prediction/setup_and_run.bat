@echo off
echo ========================================
echo Setting up Diabetes App with MySQL
echo ========================================

echo.
echo Step 1: Creating database in MySQL...
echo (If prompted for password, just press Enter)
mysql -u root -e "CREATE DATABASE IF NOT EXISTS diabetes_app;" 2>nul

if %ERRORLEVEL% NEQ 0 (
    echo Failed to create database. Make sure XAMPP MySQL is running!
    echo Press any key to exit...
    pause >nul
    exit /b 1
)

echo Database created successfully!
echo.

echo Step 2: Creating tables...
python create_mysql_tables.py

if %ERRORLEVEL% NEQ 0 (
    echo Failed to create tables!
    echo Press any key to exit...
    pause >nul
    exit /b 1
)

echo.
echo Step 3: Starting the app...
echo The app will open in your browser at http://127.0.0.1:5000
echo.
echo Press Ctrl+C to stop the app when done
echo.

python app.py

pause
