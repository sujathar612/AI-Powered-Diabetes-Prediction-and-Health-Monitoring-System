"""
Script to create all tables in MySQL database.
Run this once before starting the app.
"""
import sys
import os

# Add parent directory to path  
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app import app
from models import db

def create_tables():
    """Create all tables in MySQL"""
    with app.app_context():
        # This will create all tables based on models
        db.create_all()
        print("All tables created successfully in MySQL!")
        
        # List all tables
        inspector = db.inspect(db.engine)
        tables = inspector.get_table_names()
        print(f"Tables created: {tables}")

if __name__ == '__main__':
    create_tables()
    print("\nDatabase setup complete! You can now run your app.")
