from models import db, User
from config import Config
from flask import Flask

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)

with app.app_context():
    users = User.query.all()
    print("User Entries:")
    for user in users:
        print(f"ID: {user.id}, Username: {user.username}, Email: {user.email}")
