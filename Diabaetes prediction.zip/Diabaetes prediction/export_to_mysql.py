import sqlite3
import mysql.connector
from mysql.connector import Error

# SQLite database path
sqlite_db = 'instance/app.db'

# MySQL connection details (update with your XAMPP MySQL credentials)
mysql_host = 'localhost'
mysql_user = 'root'  # Default XAMPP user
mysql_password = ''  # Default XAMPP password (empty)
mysql_database = 'diabetes_app'  # New database name

def create_mysql_connection():
    try:
        connection = mysql.connector.connect(
            host=mysql_host,
            user=mysql_user,
            password=mysql_password,
            database=mysql_database
        )
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

def export_table(cursor_sqlite, table_name, mysql_cursor):
    # Get column names
    cursor_sqlite.execute(f"PRAGMA table_info({table_name})")
    columns = [col[1] for col in cursor_sqlite.fetchall()]

    # Get data
    cursor_sqlite.execute(f"SELECT * FROM {table_name}")
    rows = cursor_sqlite.fetchall()

    if rows:
        # Create table in MySQL
        create_table_sql = f"CREATE TABLE IF NOT EXISTS {table_name} ("
        for col in columns:
            create_table_sql += f"{col} TEXT, "
        create_table_sql = create_table_sql.rstrip(', ') + ")"

        mysql_cursor.execute(create_table_sql)

        # Insert data
        placeholders = ', '.join(['%s'] * len(columns))
        insert_sql = f"INSERT INTO {table_name} VALUES ({placeholders})"
        mysql_cursor.executemany(insert_sql, rows)

def main():
    # Connect to SQLite
    sqlite_conn = sqlite3.connect(sqlite_db)
    sqlite_cursor = sqlite_conn.cursor()

    # Connect to MySQL
    mysql_conn = create_mysql_connection()
    if not mysql_conn:
        return

    mysql_cursor = mysql_conn.cursor()

    # Get all table names
    sqlite_cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [table[0] for table in sqlite_cursor.fetchall() if table[0] != 'sqlite_sequence']

    for table in tables:
        print(f"Exporting table: {table}")
        export_table(sqlite_cursor, table, mysql_cursor)

    mysql_conn.commit()
    mysql_cursor.close()
    mysql_conn.close()
    sqlite_cursor.close()
    sqlite_conn.close()

    print("Export completed. You can now view the data in phpMyAdmin.")

if __name__ == "__main__":
    main()
